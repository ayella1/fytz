document.addEventListener("DOMContentLoaded", () => {
    const update_time = 30 * 60 * 1000; //update weather every 30 min
    const lastUpdate = localStorage.getItem('weather_timestamp');
    const now = new Date().getTime();
    const savedFit = localStorage.getItem('pendingOutfit');
    // For weather update only every 30min
    // If 30 mins passed OR cache was manually cleared (set to '0')
    if (!lastUpdate || (now - lastUpdate) > update_time || lastUpdate === '0') {
        updateWeather();
    } else {
        // Use saved data
        const savedData = JSON.parse(localStorage.getItem('weather_cache'));
        if (savedData) {
            displayWeather(savedData);
        } else {
            updateWeather();
        }
    }

    // Check if we came here from another page wanting a recommendation
    if (window.location.pathname === "/" && localStorage.getItem('pendingRecommendation') === 'true') {
        localStorage.removeItem('pendingRecommendation');
        getRecommendation();
    }

    if (window.location.pathname === "/" && savedFit) {
        const outfit = JSON.parse(savedFit);
        localStorage.removeItem('pendingOutfit'); // Clear memory

        // Using selectItem function to dress the mannequin
        if (outfit.shirts.img) selectItem('shirts', outfit.shirts.img, outfit.shirts.id);
        if (outfit.pants.img) selectItem('pants', outfit.pants.img, outfit.pants.id);
        if (outfit.shoes.img) selectItem('shoes', outfit.shoes.img, outfit.shoes.id);
        if (outfit.shades.img) selectItem('shades', outfit.shades.img, outfit.shades.id);
    }
});

//get weather update for given location
function updateWeather() {
    fetch('/api/weather')
        .then(res => res.json())
        .then(data => {
            // Save to browser memory
            localStorage.setItem('weather_cache', JSON.stringify(data));
            localStorage.setItem('weather_timestamp', new Date().getTime());
            displayWeather(data);
        })
        .catch(err => console.error("Weather update failed:", err));
}

// takes weather data and send to screen to dispaly current weather scrolling bar
function displayWeather(data) {
    const isRainy = data.forecast.toLowerCase().includes("rain") || data.forecast.toLowerCase().includes("showers");
    let message = "";
    if (data.alert) {
        message += `<strong>${data.alert}</strong>`;
    }
    if (isRainy) {
        if (message) message += "<br>";
        message += `<small>(${data.temp}°F) - Chance of rain. Grab an umbrella!</small>`;
    }
    else if (data.temp >= 90) {
        if (message) message += "<br>";
        message += `<small>Extremely Hot day (${data.temp}°F) - Wear Sunglasses and Stay Hydrated!</small>`;
    }
    else if (data.temp >= 40 && data.temp <= 50) {
        if (message) message += "<br>";
        message += `<small>Chilly day (${data.temp}°F) - Wear layers and a light jacket!</small>`;
    }
    else if (data.temp >= 20 && data.temp < 40) {
        if (message) message += "<br>";
        message += `<small>Cold day (${data.temp}°F) - Wear 2-3 layers and a warm coat!</small>`;
    }
    else if (data.temp < 20) {
        if (message) message += "<br>";
        message += `<small>Extremely cold (${data.temp}°F) - Heavy coat and gloves required!</small>`;
    }
    // Update layout.html nav bar weather elements
    try {
        const navAlertContainer = document.getElementById('nav-alert-container');
        const navAlertText = document.getElementById('nav-alert-text');

        if (navAlertContainer && navAlertText) {
            if (message != "") {
                navAlertContainer.classList.remove('d-none');
                //navAlertText.innerHTML = message;
                let cleanMessage = message.replace(/<br>/g, " | ").replace(/<\/?[^>]+(>|$)/g, "");
                let iconPrefix = "";
                if (data.alert) iconPrefix = "⚠️ ";
                else if (isRainy) iconPrefix = "☔ ";
                else if (data.temp >= 90) iconPrefix = "🔥 ";
                else if (data.temp <= 50) iconPrefix = "🧥 ";
                navAlertText.innerText = iconPrefix + cleanMessage;
            } else {
                navAlertContainer.classList.add('d-none');
            }
        }

        if(document.getElementById('nav-temp')) document.getElementById('nav-temp').innerText = data.temp + "°F";
        if(document.getElementById('nav-forecast')) document.getElementById('nav-forecast').innerText = data.forecast;
        if(document.getElementById('nav-location')) document.getElementById('nav-location').innerText = data.location;

        const navIcon = document.getElementById('nav-weather-icon');
        if (navIcon && data.icon) {
            navIcon.src = data.icon;
            navIcon.style.display = 'block';
        }
    }
    catch (error) {
        console.error("Weather update failed for layout:", error);
    }

    // Update home weather elements
    try {
        const alertBox = document.getElementById('weather-alert');
        const alertText = document.getElementById('alert-text');

        if (alertBox && alertText) {
            if (message != "") {
                alertBox.classList.remove('d-none');
                let iconPrefix = "";
                if (data.alert) iconPrefix = "⚠️ ";
                else if (isRainy) iconPrefix = "☔ ";
                else if (data.temp >= 90) iconPrefix = "🔥 ";
                else if (data.temp <= 50) iconPrefix = "🧥 ";
                alertText.innerHTML = iconPrefix + message;
            } else {
                alertBox.classList.add('d-none');
            }
        }

        if(document.getElementById('temp')) document.getElementById('temp').innerText = data.temp + "°F";
        if(document.getElementById('forecast')) document.getElementById('forecast').innerText = data.forecast;
        if(document.getElementById('location')) document.getElementById('location').innerText = data.location;

        const iconImg = document.getElementById('weather-icon');

        if (iconImg && data.icon) {
            iconImg.setAttribute('src', data.icon);

            iconImg.src = data.icon;
            iconImg.style.display = 'block';
        }
    }
    catch (error) {
        console.error("Weather update failed for (home):", error);
    }
}

//if need fresh weather update in middle of 30min
function resetWeatherCache() {
    // Reset timestamp to '0' so the timer logic above thinks it's expired
    localStorage.setItem('weather_timestamp', '0');
}

//if you like the output created this saves to history
function finalizeOutfit() {
    const hasItems = Object.values(selectedOutfitIds).some(id => id !== null);
    if (!hasItems) return;

    fetch('/finalize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(selectedOutfitIds)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert("Fit saved to history!");
            clearMannequin();
        }
    });
}


// Toggle Favorite Status for an Outfit
function toggleOutfitFav(id) {
    fetch('/toggle_outfit_favorite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ outfit_id: id })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            const btn = document.getElementById('outfit-heart-' + id);
            btn.innerText = data.new_status === 1 ? '❤️' : '🤍';
        }
    });
}

// Delete an Outfit from the database
function deleteOutfit(id) {
    if (confirm("Are you sure you want to delete this look?")) {
        fetch('/delete_outfit/' + id, { method: 'POST' })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // Remove the card from the UI smoothly
                location.reload();
            }
        });
    }
}


//password visible toggle
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('i');

    if (input.type === "password") {
        input.type = "text";
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        input.type = "password";
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}

//if you want delete profile pic
function confirmDeleteProfile() {
    return confirm("Are you sure you want to remove your profile picture? This cannot be undone.");
}

// Function called when you click an outfit in History
function loadOutfitToMannequin(shirtId, shirtImg, pantsId, pantsImg, shoesId, shoesImg, shadesId, shadesImg) {
    const outfit = {
        shirts: { id: shirtId, img: shirtImg },
        pants: { id: pantsId, img: pantsImg },
        shoes: { id: shoesId, img: shoesImg },
        shades: { id: shadesId, img: shadesImg }
    };
    // Save to browser memory and go home
    localStorage.setItem('pendingOutfit', JSON.stringify(outfit));
    window.location.href = "/";
}

//funtion to make settings button appear and disappear
function trackChange(fieldId) {
    const saveBtn = document.getElementById(`${fieldId}-save`);
    const cancelBtn = document.getElementById(`${fieldId}-cancel`);
    const options = document.getElementById(`${fieldId}-options`);
    const removeBtn = document.getElementById(`${fieldId}-remove-btn`);

    if (!saveBtn) return; // Safety check

    const form = saveBtn.closest('form');
    const inputs = form.querySelectorAll('input, select');
    let isChanged = false;

    inputs.forEach(input => {
        if (input.type === "file") {
            if (input.files.length > 0) isChanged = true;
        }
        else if (input.type === "checkbox") {
            if (input.checked !== input.defaultChecked) isChanged = true;
        }
        else if (input.type === "password") {
            if (input.value.length > 0) isChanged = true;
        }
        else if (input.value !== input.defaultValue) {
            isChanged = true;
        }
    });

    if (isChanged) {
        saveBtn.disabled = false;
        cancelBtn.classList.remove('d-none');
        if (options) options.classList.remove('d-none');
        if (removeBtn) removeBtn.classList.add('d-none');
    } else {
        saveBtn.disabled = true;
        cancelBtn.classList.add('d-none');
        if (options) options.classList.add('d-none');
        if (removeBtn) removeBtn.classList.remove('d-none');
    }
}

//generic cancel button support fuction
function cancelChange(fieldId) {
    const saveBtn = document.getElementById(`${fieldId}-save`);
    const cancelBtn = document.getElementById(`${fieldId}-cancel`);
    const options = document.getElementById(`${fieldId}-options`);
    const removeBtn = document.getElementById(`${fieldId}-remove-btn`);

    if (!saveBtn) return;

    const form = saveBtn.closest('form');
    const inputs = form.querySelectorAll('input, select');

    inputs.forEach(input => {
        if (input.type === "file") input.value = "";
        else if (input.type === "checkbox") input.checked = input.defaultChecked;
        else if (input.type === "password") input.value = "";
        else input.value = input.defaultValue;
    });

    saveBtn.disabled = true;
    cancelBtn.classList.add('d-none');
    if (options) options.classList.add('d-none');
    if (removeBtn) removeBtn.classList.remove('d-none');
}
