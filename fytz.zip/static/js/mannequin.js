// 1. GLOBAL STATE
let currentCategory = 'all';
let currentPage = 1;
let totalPages = 1;
let selectedOutfitIds = { shirts: null, pants: null, shoes: null, shades: null };
let activeElement = null;
let initialX, initialY;

// Sound Logic trash or delete ---
const crunchSound = new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3');

// laods WARDROBE LOADING
function loadWardrobe(category = 'all', page = 1) {
    currentCategory = category;
    currentPage = page;
    const searchTerm = document.getElementById('wardrobe-search')?.value.toLowerCase().trim() || "";
    const onlyFavs = document.getElementById('fav-toggle')?.checked || false;

    fetch(`/api/wardrobe?category=${category}&page=${page}&q=${searchTerm}&favs=${onlyFavs}`)
        .then(res => res.json())
        .then(data => {
            renderWardrobe(data.items);
            updatePagination(data.current_page, data.total_pages);
        });
}

//render wardrobe with favorites
function renderWardrobe(items) {
    const grid = document.getElementById('wardrobe-grid');
    grid.innerHTML = '';

    if (!items || items.length === 0) {
        grid.innerHTML = '<div class="col-12 text-center py-5 fw-bold small">NO ITEMS FOUND</div>';
        return;
    }

    items.forEach(item => {
        const isFav = item.is_favorite ? '❤️' : '♡';
        grid.insertAdjacentHTML('beforeend', `
            <div class="col-xl-3 col-lg-4 col-6 mb-3">
                <div class="card h-100 border-0 shadow-sm wardrobe-item-card"
                     onclick="selectItem('${item.category}', '${item.image_file}', ${item.id})"
                     style="cursor: pointer; border-radius: 12px; position: relative;">

                    <!-- THE MISSING CHECKBOX -->
                    <div class="position-absolute" style="top: 10px; left: 10px; z-index: 20;">
                        <input type="checkbox" class="form-check-input wardrobe-check" value="${item.id}"
                               onclick="event.stopPropagation()"
                               style="width: 18px; height: 18px; border: 2px solid #000;">
                    </div>

                    <!-- Heart Toggle -->
                    <div class="position-absolute" style="top: 5px; right: 8px; z-index: 20;"
                         onclick="event.stopPropagation(); toggleFavorite(${item.id})">
                        <span id="heart-${item.id}" style="font-size: 1.2rem;">${isFav}</span>
                    </div>

                    <img src="/static/uploads/${item.image_file}" class="card-img-top p-3"
                         style="height: 120px; object-fit: contain; pointer-events: none;">

                    <div class="card-body text-center p-1">
                        <small class="fw-bold text-uppercase" style="font-size: 0.6rem;">${item.category}</small>
                    </div>
                </div>
            </div>
        `);
    });
}


//dress recommendation for magic wand
function getRecommendation() {
    console.log("Wand Clicked!");
    const sparkle = document.getElementById('wand-sparkle');
    if (sparkle) sparkle.classList.remove('d-none');

    // Redirect if not home
    if (window.location.pathname !== "/") {
        localStorage.setItem('pendingRecommendation', 'true');
        window.location.href = "/";
        return;
    }

    const isFavOnly = document.getElementById('fav-toggle')?.checked || false;

    fetch(`/api/recommend?favorites_only=${isFavOnly}`)
        .then(res => res.json())
        .then(outfit => {
            if (typeof clearMannequin === "function") clearMannequin();

            Object.entries(outfit).forEach(([category, item]) => {

                const actualItem = Array.isArray(item) ? item[0] : item;

                if (actualItem && actualItem.image_file) {
                    selectItem(category, actualItem.image_file, actualItem.id);
                }
            });

            const hint = document.getElementById('mannequin-hint');
            if (hint) hint.style.display = 'none';
            if (sparkle) sparkle.classList.add('d-none');
        })
        .catch(err => {
            console.error("AI Error:", err);
            if (sparkle) sparkle.classList.add('d-none');
        });
}

function selectItem(category, imageFile, itemId) {
    let slotId = category;

    // DRESS RULE: Anchors to shirt slot but keeps dress category for styling
    if (category === 'dresses') {
        slotId = 'shirts';
        selectedOutfitIds['shirts'] = itemId;
    } else {
        selectedOutfitIds[category] = itemId;
    }

    const slot = document.getElementById('slot-' + slotId);
    if (!slot) return;

    const configs = {
        dresses: { w: "180px", t: "90px", l: "20px" },
        shades:  { w: "55px", t: "45px", l: "82px" },
        shirts:  { w: "160px", t: "90px", l: "30px" },
        pants:   { w: "135px", t: "190px", l: "42px" },
        shoes:   { w: "110px", t: "320px", l: "55px" }
    };

    const c = configs[category];

    slot.innerHTML = `
        <img src="/static/uploads/${imageFile}"
             class="draggable-item"
             data-category="${category}"
             style="width: ${c.w}; top: ${c.t}; left: ${c.l}; position: absolute;">`;

    updateActionButtons();
}

// DRAG functionality
document.addEventListener("mousedown", (e) => {
    const item = e.target.closest(".draggable-item");
    if (!item) return;
    activeElement = item;
    // MATH FIX: Calculate based on CSS style to prevent disappearing
    initialX = e.clientX - parseFloat(activeElement.style.left || 0);
    initialY = e.clientY - parseFloat(activeElement.style.top || 0);
    document.addEventListener("mousemove", drag);
    document.addEventListener("mouseup", stopDrag);
});

function drag(e) {
    if (!activeElement) return;
    activeElement.classList.add('is-dragging');
    activeElement.style.left = (e.clientX - initialX) + "px";
    activeElement.style.top = (e.clientY - initialY) + "px";

    const bin = document.getElementById('trash-bin');
    const binRect = bin.getBoundingClientRect();
    const isOver = (e.clientX >= binRect.left && e.clientX <= binRect.right && e.clientY >= binRect.top && e.clientY <= binRect.bottom);

    bin.style.color = isOver ? "red" : "black";
    bin.style.transform = isOver ? "scale(1.4)" : "scale(1)";
    bin.style.opacity = isOver ? "1" : "0.3";
}

function stopDrag(e) {
    if (!activeElement) return;
    const bin = document.getElementById('trash-bin');
    const binRect = bin.getBoundingClientRect();
    const isOver = (e.clientX >= binRect.left && e.clientX <= binRect.right && e.clientY >= binRect.top && e.clientY <= binRect.bottom);

    if (isOver) {
        const cat = activeElement.getAttribute('data-category');
        selectedOutfitIds[cat] = null;
        activeElement.remove();
        crunchSound.play().catch(()=>{});
        updateActionButtons();
    }
    activeElement.classList.remove('is-dragging');
    bin.style.color = "black";
    bin.style.transform = "scale(1)";
    bin.style.opacity = "0.3";
    activeElement = null;
    document.removeEventListener("mousemove", drag);
    document.removeEventListener("mouseup", stopDrag);
}

// UTILS
function updateActionButtons() {
    const hasItems = Object.values(selectedOutfitIds).some(id => id !== null);
    document.getElementById('finalize-btn').style.display = hasItems ? 'inline-block' : 'none';
    document.getElementById('clear-btn').style.display = hasItems ? 'inline-block' : 'none';
    document.getElementById('mannequin-hint').style.display = hasItems ? 'none' : 'block';
}

function clearMannequin() {
    document.querySelectorAll('.cloth-slot').forEach(s => s.innerHTML = '');
    selectedOutfitIds = { shirts: null, pants: null, shoes: null, shades: null };
    updateActionButtons();
}

function updatePagination(current, total) {
    totalPages = total;
    document.getElementById('page-info').innerText = `Page ${current} of ${total}`;
    document.getElementById('prev-page').disabled = (current <= 1);
    document.getElementById('next-page').disabled = (current >= total);
}

function changePage(step) { if (currentPage + step >= 1 && currentPage + step <= totalPages) loadWardrobe(currentCategory, currentPage + step); }

function setCategory(cat, btn) {
    // Find all tab buttons and remove the 'active' highlight
    document.querySelectorAll('.nav-pills .nav-link').forEach(link => {
        link.classList.remove('active');
    });

    // If a button was clicked, make it the 'active' one (Black background)
    if (btn) {
        btn.classList.add('active');
    }

    //  Load the data
    loadWardrobe(cat, 1);
}

function filterByTags() { loadWardrobe(currentCategory, 1); }

function toggleFavorite(itemId) {
    fetch('/toggle_favorite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ item_id: itemId })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            // Check if the "Favs Only" switch is currently ON
            const favToggle = document.getElementById('fav-toggle');
            const isFavOnlyMode = favToggle ? favToggle.checked : false;

            // If we just unfavorited (new_status === 0) while in Favs Only mode
            if (isFavOnlyMode && data.new_status === 0) {
                // Refresh the wardrobe so the item disappears immediately
                loadWardrobe(currentCategory, currentPage);
            } else {
                // Otherwise, just swap the heart icon like normal
                const heart = document.getElementById(`heart-${itemId}`);
                if (heart) {
                    heart.innerText = data.new_status === 1 ? "❤️" : "♡";
                    // Optional: color update
                    heart.style.color = data.new_status === 1 ? "#ff0000" : "#000000";
                }
            }
        }
    })
    .catch(err => console.error("Heart toggle failed:", err));
}


// WATCHER: Shows/Hides the Delete button based on checks
document.addEventListener('change', (e) => {
    if (e.target.classList.contains('wardrobe-check')) {
        updateDeleteButtonVisibility();
    }
});

function updateDeleteButtonVisibility() {
    const anyChecked = document.querySelectorAll('.wardrobe-check:checked').length > 0;
    const deleteBtn = document.getElementById('bulk-delete-btn');
    if (deleteBtn) {
        deleteBtn.style.display = anyChecked ? 'inline-block' : 'none';
    }
}

// SELECT ALL: Only targets items currently visible on the page
function toggleSelectAll() {
    const checks = document.querySelectorAll('.wardrobe-check');
    const allBtn = document.getElementById('select-all-btn');

    // If everything on this page is checked, uncheck all. Otherwise, check all.
    const isAllSelected = Array.from(checks).every(c => c.checked);

    checks.forEach(c => c.checked = !isAllSelected);
    allBtn.innerText = isAllSelected ? "Select All" : "Deselect All";

    updateDeleteButtonVisibility();
}

// THE ACTUAL DELETE ACTION
function bulkDelete() {
    const selectedIds = Array.from(document.querySelectorAll('.wardrobe-check:checked')).map(c => c.value);

    if (selectedIds.length === 0) return;

    if (confirm(`Are you sure you want to delete ${selectedIds.length} items?`)) {
        fetch('/api/wardrobe/delete_bulk', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ids: selectedIds})
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                crunchSound.play().catch(e => console.log("Audio play blocked"));
                // Refresh the current page to show remaining items
                loadWardrobe(currentCategory, currentPage);
                updateDeleteButtonVisibility();
            }
        });
    }
}

document.addEventListener("DOMContentLoaded", () => loadWardrobe('all', 1));
